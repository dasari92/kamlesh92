package com.ecg.services;
import java.sql.SQLException;
import com.ecg.beans.User;
import com.ecg.daointerfaces.UserQuestionDao;
import com.ecg.daoimplementations.UserQuestionDaoImplementation;
public class UserQuestionService {
	public int postQuestion(User user)throws ClassNotFoundException,SQLException{
		UserQuestionDao userQDao = new UserQuestionDaoImplementation();
		return userQDao.postQuestion(user);
	}
}