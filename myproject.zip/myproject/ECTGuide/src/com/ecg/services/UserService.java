package com.ecg.services;

import java.sql.ResultSet;
import java.sql.SQLException;
import com.ecg.daoimplementations.UserDaoImplementation;
import com.ecg.daointerfaces.UserDao;

public class UserService {
	public  ResultSet displayQuestions() throws ClassNotFoundException, SQLException{
		UserDao userDao=new UserDaoImplementation();
	      return  userDao.displayQuestions();
	}
}
