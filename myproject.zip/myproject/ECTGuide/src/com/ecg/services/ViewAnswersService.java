package com.ecg.services;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Array;
//import java.util.List;

import com.ecg.daointerfaces.ViewAnswersDao;
import com.ecg.daoimplementations.ViewAnswersDaoImplementation;
public class ViewAnswersService {
	public ResultSet viewAnswers(int qid)throws ClassNotFoundException,SQLException{
		ViewAnswersDao viewAnswersDao = new ViewAnswersDaoImplementation();
		return viewAnswersDao.viewAnswers(qid);
	}
}