package com.ecg.services;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.ecg.beans.Registration;
import com.ecg.daoimplementations.RegistrationDaoImplementation;
import com.ecg.daointerfaces.RegistrationDao;
public class RegistrationService {
	   public int addNewUser(Registration registration) throws ClassNotFoundException,SQLException{
		      RegistrationDao registrationDao=new RegistrationDaoImplementation();
		     return  registrationDao.addNewUser(registration);
		    
	   }
           public ResultSet getDetails(Registration registration) throws ClassNotFoundException,SQLException{
                    RegistrationDao registrationDao=new RegistrationDaoImplementation();
                    return  registrationDao.getDetails(registration);
           }
}

