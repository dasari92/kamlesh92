package com.ecg.services;

import java.sql.SQLException;
import com.ecg.daoimplementations.DeleteUserDaoImplementation;
import com.ecg.daointerfaces.DeleteUserDao;

public class DeleteUserService {
	public int deleteUser(int id) throws ClassNotFoundException,SQLException{
	     DeleteUserDao deleteDao=new DeleteUserDaoImplementation();
	      return  deleteDao.deleteUser(id);
}
}
