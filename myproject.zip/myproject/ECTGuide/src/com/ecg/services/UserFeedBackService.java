package com.ecg.services;
import java.sql.SQLException;
import com.ecg.beans.Feedback;
import com.ecg.daointerfaces.UserFeedBackDao;
import com.ecg.daoimplementations.UserFeedBackDaoImplementation;
public class UserFeedBackService {
	public int sendFeedback(Feedback feedback) throws ClassNotFoundException,SQLException{
	      UserFeedBackDao feedbackDao =new  UserFeedBackDaoImplementation();
	      return  feedbackDao.sendFeedback(feedback);
	}
}
