package com.ecg.services;
import java.sql.SQLException;
import com.ecg.beans.Guide;
import com.ecg.daoimplementations.GuideAnswerDaoImplementation;
import com.ecg.daointerfaces.GuideAnswerDao;
public  class GuideAnswerService {
	   public int guideAnswer(Guide guide) throws ClassNotFoundException,SQLException{
		      GuideAnswerDao answerDao=new GuideAnswerDaoImplementation();
		      return  answerDao.guideAnswer(guide);
	   }
}
