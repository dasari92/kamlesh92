package com.ecg.services;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Array;
//import java.util.List;

import com.ecg.daointerfaces.ViewFeedBackDao;
import com.ecg.daoimplementations.ViewFeedBackDaoImplementation;
public class ViewFeedBackService {
	public ResultSet viewFeedBack(int gid)throws ClassNotFoundException,SQLException{
		ViewFeedBackDao viewFeedBackDao = new ViewFeedBackDaoImplementation();
		return viewFeedBackDao.viewFeedBack(gid);
	}
}