package com.ecg.services;
import java.sql.SQLException;
import com.ecg.beans.Login;
import com.ecg.daoimplementations.LoginDaoImplementation;
import com.ecg.daointerfaces.LoginDao;
public class LoginService {
	   public String validateUser(Login login) throws ClassNotFoundException,SQLException{
		      LoginDao loginDao=new LoginDaoImplementation();
		      return  loginDao.validateUser(login);
		    
	   }
}

