
package com.ecg.daoimplementations;
//import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;

import com.ecg.daointerfaces.ViewAnswersDao;
import com.ecg.utilities.DataBaseConnectionUtility;
public class ViewAnswersDaoImplementation implements ViewAnswersDao{
	public ResultSet viewAnswers(int qid)throws ClassNotFoundException,SQLException{
		ResultSet rs=null;
		Connection con = DataBaseConnectionUtility.getConnection();
		//String query=;
        PreparedStatement ps = con.prepareStatement("select guideid,questionid,answers from ECG_GUIDE  where questionid=?");
        ps.setInt(1,qid);
        rs=ps.executeQuery();
        return rs;  
	}
}
