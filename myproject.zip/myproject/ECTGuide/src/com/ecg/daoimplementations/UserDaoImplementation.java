package com.ecg.daoimplementations;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.ecg.daointerfaces.UserDao;
import com.ecg.utilities.DataBaseConnectionUtility;

public class UserDaoImplementation implements UserDao{
	public  ResultSet displayQuestions() throws ClassNotFoundException,SQLException{
			 ResultSet rs=null;
			 Connection con = DataBaseConnectionUtility.getConnection();
             String query="select u.questionid,u.question from ECG_USER u,ECG_REGISTRATION g where u.userid=g.id";
             Statement st = con.createStatement();
             rs=st.executeQuery(query);
             return rs;
	}

}