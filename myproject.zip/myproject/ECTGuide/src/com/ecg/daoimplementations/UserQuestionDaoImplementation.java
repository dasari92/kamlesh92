
package com.ecg.daoimplementations;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.sql.Statement;
import com.ecg.beans.User;
import com.ecg.daointerfaces.UserQuestionDao;
import com.ecg.utilities.DataBaseConnectionUtility;
public class UserQuestionDaoImplementation implements UserQuestionDao{
	int days;
	int result;
	int count;
	public int postQuestion(User user) throws ClassNotFoundException, SQLException{
		  	Connection con = DataBaseConnectionUtility.getConnection();
		  	PreparedStatement psmt = con.prepareStatement("insert into ECG_USER values(?,?,ECG_QID.NEXTVAL)");
		    PreparedStatement psmt3 = con.prepareStatement("select count(question) from ecg_user where userid=? ");
		    psmt3.setInt(1, user.getUserId());
		    ResultSet res1=psmt3.executeQuery();
		    while(res1.next()){
		    	count=res1.getInt(1);
		    }
		    PreparedStatement psmt2 = con.prepareStatement("select round((sysdate-reg_date)) days from ecg_registration where id=? ");
	    	psmt2.setInt(1,user.getUserId());
	    	ResultSet res=psmt2.executeQuery();
	    	while(res.next()){
	    		days= res.getInt(1);
	    	}
		    if((count<100)&&(days<30)){		   
		    		PreparedStatement psmt1=con.prepareStatement("select * from ECG_REGISTRATION where id=?");		  	
		    		psmt1.setInt(1,user.getUserId());
		    		ResultSet rs=psmt1.executeQuery();
		    		if(rs.next()==true){
		    			psmt.setInt(1,user.getUserId());
		    			psmt.setString(2,user.getQuestion()); 
		    			result =psmt.executeUpdate(); 
		    		}
		    		else{
		    			result=0;
		    		}
		  	
		    		DataBaseConnectionUtility.closeConnection(con);
		    }
		    return result; 
     }

}



