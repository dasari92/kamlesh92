package com.ecg.daoimplementations;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.ecg.beans.Registration;
import com.ecg.daointerfaces.RegistrationDao;
import com.ecg.utilities.DataBaseConnectionUtility;
public class RegistrationDaoImplementation implements RegistrationDao {
		 public int addNewUser(Registration registration) throws ClassNotFoundException, SQLException{
			// System.out.println("connected");
		  	Connection con = DataBaseConnectionUtility.getConnection();
		        //System.out.println("connected");
                //PreparedStatement psmt1=con.prepareStatement("select sysdate from dual");
		        PreparedStatement psmt = con.prepareStatement("insert into ECG_REGISTRATION values(ECG_SQ_ID.NEXTVAL,?,?,?,?,?)");
		        //ResultSet rs=null;
		       // rs=psmt1.executeQuery();
            java.util.Date date = new java.util.Date();
            long t=date.getTime();
            java.sql.Date sqlDate = new java.sql.Date(t);
		   	psmt.setString(1,registration.getName());   
		  	psmt.setString(2,registration.getPassword());
		  	psmt.setString(3,registration.getRole());
		  	psmt.setDouble(4,registration.getAmount());  
            psmt.setDate(5,sqlDate);
			int result =psmt.executeUpdate(); 
			DataBaseConnectionUtility.closeConnection(con);
			return result;
		 
                 }
		 public ResultSet getDetails(Registration registration)throws ClassNotFoundException, SQLException{
			 ResultSet rs=null;
			 Connection con = DataBaseConnectionUtility.getConnection();
             String query="select * from ECG_REGISTRATION where name=? and password=?";
             PreparedStatement ps = con.prepareStatement(query);
             ps.setString(1,registration.getName());
             ps.setString(2,registration.getPassword());
             rs=ps.executeQuery();
             return rs;
      } 
                 
}

