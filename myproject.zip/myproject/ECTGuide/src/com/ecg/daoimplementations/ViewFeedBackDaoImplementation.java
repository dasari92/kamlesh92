
package com.ecg.daoimplementations;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.ecg.daointerfaces.ViewFeedBackDao;
import com.ecg.utilities.DataBaseConnectionUtility;
public class ViewFeedBackDaoImplementation implements ViewFeedBackDao{
	public ResultSet viewFeedBack(int gid)throws ClassNotFoundException,SQLException{
		ResultSet rs=null;
		Connection con = DataBaseConnectionUtility.getConnection();
		//String query=;
        PreparedStatement ps = con.prepareStatement("select feedback from ECG_FEEDBACK where guideid=?");
        ps.setInt(1,gid);
        rs=ps.executeQuery();
        return rs;  
	}
}
