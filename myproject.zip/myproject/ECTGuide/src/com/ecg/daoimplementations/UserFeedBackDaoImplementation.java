package com.ecg.daoimplementations;
import com.ecg.beans.Feedback;
import com.ecg.daointerfaces.UserFeedBackDao;
import com.ecg.utilities.DataBaseConnectionUtility;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class UserFeedBackDaoImplementation implements UserFeedBackDao{
	int amountcredited;
	public int sendFeedback(Feedback feedback) throws ClassNotFoundException,SQLException{
	Connection con = DataBaseConnectionUtility.getConnection();
	String ftext = feedback.getFeebackText();
	if(ftext.equals("Best")){
		 amountcredited=100;		
	}
	else{
            amountcredited=0;
	}
	System.out.println(amountcredited);
	PreparedStatement psmt = con.prepareStatement("insert into ECG_FEEDBACK	 values(?,?,?)");
	PreparedStatement psmt1=con.prepareStatement("select * from ECG_REGISTRATION where id=?");
	 psmt1.setInt(1,feedback.getGuideId());
	 int result;
	ResultSet rs = null;
	rs=psmt1.executeQuery();
	if(rs.next()==true){
		psmt.setInt(1,feedback.getGuideId());
		psmt.setString(2,feedback.getFeebackText());
		psmt.setInt(3,amountcredited);
		result =psmt.executeUpdate();
	}
	else{
		result=0;
	}
	DataBaseConnectionUtility.closeConnection(con);
	return result;
	}
}