package com.ecg.daoimplementations;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.ecg.beans.Guide;
import com.ecg.daointerfaces.GuideAnswerDao;
import com.ecg.utilities.DataBaseConnectionUtility;
import java.sql.PreparedStatement;
public class GuideAnswerDaoImplementation implements GuideAnswerDao{
	 public int guideAnswer(Guide guide) throws ClassNotFoundException, SQLException{
		 Connection con = DataBaseConnectionUtility.getConnection();
         //System.out.println("connected");
		 PreparedStatement psmt = con.prepareStatement("insert into ECG_GUIDE values(?,?,?)");
		 PreparedStatement psmt1=con.prepareStatement("select * from ECG_REGISTRATION where id=?");
		 psmt1.setInt(1,guide.getGuideId());
		 int result;
		 ResultSet rs=psmt1.executeQuery();
		 if(rs.next()==true){
			 psmt.setInt(1,guide.getGuideId());
			 psmt.setInt(2,guide.getQuestionId()); 
			 psmt.setString(3,guide.getAnswers()); 
			 result =psmt.executeUpdate(); 
		 }
		 else{
		  	result=0;
		 }
		 DataBaseConnectionUtility.closeConnection(con);
		 return result; 
		 
	 }
}