package com.ecg.daoimplementations;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.ecg.beans.Login;
import com.ecg.daointerfaces.LoginDao;
import com.ecg.utilities.DataBaseConnectionUtility;
import java.sql.PreparedStatement;
public class LoginDaoImplementation implements LoginDao{
		 public String validateUser(Login login) throws ClassNotFoundException, SQLException{
			// System.out.println("connected");
		  	Connection con = DataBaseConnectionUtility.getConnection();
                        //System.out.println("connected");
                        String query="select role from ECG_REGISTRATION where id=? and password=?";
                        PreparedStatement ps = con.prepareStatement(query);
                        ps.setInt(1,login.getId());
                        ps.setString(2,login.getPassword());
                        ResultSet rs=null;
                        rs=ps.executeQuery();
                        String rrole=" ";
                        while(rs.next()){
                            rrole=rs.getString("role");
                        }
			DataBaseConnectionUtility.closeConnection(con);
			return rrole;
		 }
}

