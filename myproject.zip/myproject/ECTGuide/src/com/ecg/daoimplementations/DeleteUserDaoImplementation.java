package com.ecg.daoimplementations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.ecg.daointerfaces.DeleteUserDao;
import com.ecg.utilities.DataBaseConnectionUtility;

public class DeleteUserDaoImplementation implements DeleteUserDao{
  public int deleteUser(int id)throws ClassNotFoundException, SQLException{
		Connection con = DataBaseConnectionUtility.getConnection();
		 PreparedStatement psmt = con.prepareStatement("delete from ECG_REGISTRATION where id=?");
		 psmt.setInt(1,id);
		 int result = psmt.executeUpdate();
		 DataBaseConnectionUtility.closeConnection(con);
		 return result;
		 
  }
}