package com.ecg.controllers;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecg.services.UserService;

/**
 * Servlet implementation class UserServlet
 */
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		UserService userService = new UserService() ;		
		try{	
			  
                        ResultSet res = userService.displayQuestions();
               			 	HttpSession session=request.getSession();
               			 	while(res.next()){
               				 session.setAttribute("questionid",res.getInt("questionid"));
               				 session.setAttribute("question",res.getString("question"));	
               				 request.setAttribute("msg", "Successfully registered");
               				 RequestDispatcher rd=request.getRequestDispatcher("/User.jsp");
               			     rd.include(request, response); 
               			 	} 
               
		}
            catch(ClassNotFoundException ce ){		           
				ce.printStackTrace();      
		// append message to log file      
            }
                catch(SQLException se){		           
	    		se.printStackTrace( );		          
		 // append message to log file		       
		}   
		//RequestDispatcher rd = request.getRequestDispatcher("/Registration.html");      
		//rd.include(request, response);
	}



		
	}


