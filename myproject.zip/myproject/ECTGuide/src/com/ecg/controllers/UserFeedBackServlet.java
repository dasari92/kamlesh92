package com.ecg.controllers;
import com.ecg.beans.Feedback;
import com.ecg.services.UserFeedBackService;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UserFeedBackServlet
 */
public class UserFeedBackServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserFeedBackServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println(request.getParameter("gid"));
		System.out.println(request.getParameter("rating"));
		int guideId = Integer.parseInt(request.getParameter("gid"));
		String rating = request.getParameter("rating");
		Feedback feedback = new Feedback();
		feedback.setFeebackText(rating);
		feedback.setGuideId(guideId);
		UserFeedBackService feedbackService=new UserFeedBackService();
		 try{
			 int res=feedbackService.sendFeedback(feedback);
			 if(res>0){
	             request.setAttribute("msg","Successfully submitted");
	             RequestDispatcher rd = request.getRequestDispatcher("/FeedBackJsp.jsp");      
	             rd.include(request, response);
	         }
	         else{
	             request.setAttribute("msg", "fail");
	             RequestDispatcher rd = request.getRequestDispatcher("/FeedBack.html");      
	             rd.include(request, response);
	         }
		 }
		 catch(ClassNotFoundException ce ){		           
				ce.printStackTrace();      
		// append message to log file      
		}
	         catch(SQLException se){		           
	 		se.printStackTrace( );		          
		 // append message to log file		       
		} 

	}

}
