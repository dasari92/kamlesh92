package com.ecg.controllers;
import com.ecg.beans.User;
import com.ecg.services.UserQuestionService;
import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class UserQuestionServlet
 */
public class UserQuestionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserQuestionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		int userId=(int)session.getAttribute("Name");
		String question = request.getParameter("qtext");
		User u = new User();
		u.setQuestion(question);
		u.setUserId(userId);
		UserQuestionService userQService = new UserQuestionService();
		try{
			int res=userQService.postQuestion(u);
			if(res>0){
				request.setAttribute("msg","Successfully Posted a question");
				RequestDispatcher rd = request.getRequestDispatcher("/PostQuestionJsp.jsp");      
		        rd.include(request, response);
			}
			else{
				request.setAttribute("msg","you are not a valid user");
				RequestDispatcher rd = request.getRequestDispatcher("/PostQuestion.html");      
		        rd.include(request, response);
			}
		}catch(ClassNotFoundException ce ){		           
			ce.printStackTrace();        
		}catch(SQLException se){		           
			se.printStackTrace( );		          	       
		}   
	}
}
