package com.ecg.controllers;

import java.io.IOException;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.ecg.beans.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecg.beans.Guide;
import com.ecg.services.ViewAnswersService;
/**
 * Servlet implementation class ViewAnswersServlet
 */
public class ViewAnswersServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewAnswersServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int qid = Integer.parseInt(request.getParameter("qid"));  
		//System.out.println("rfdeget");
		ViewAnswersService viewAnswersService = new ViewAnswersService() ;
        List<Guide> guidelist = new ArrayList<Guide>();
		//PrintWriter out=response.getWriter();
		try{		   
					
						ResultSet rs=null;
                        rs=viewAnswersService.viewAnswers(qid);
                        //HttpSession session=request.getSession();
                        Guide g=new Guide();
                        List<Guide> glist=new ArrayList<Guide>();
                        while(rs.next()){
                        	g.setGuideId(rs.getInt("guideid"));
                        	g.setAnswers(rs.getString("answers"));
                        	g.setQuestionId(rs.getInt("questionid"));
                        	glist.add(g);
                   		
                        }
                        
                        request.setAttribute("ans",glist);
                        RequestDispatcher rd = request.getRequestDispatcher("/ViewAnswersJsp.jsp");      
                        rd.include(request, response);
                       
		}		       
		catch(ClassNotFoundException ce ){		           
				ce.printStackTrace();      
		// append message to log file      
		}
        catch(SQLException se){		           
	    		se.printStackTrace( );		          
		 // append message to log file		       
		}   
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}	
}


