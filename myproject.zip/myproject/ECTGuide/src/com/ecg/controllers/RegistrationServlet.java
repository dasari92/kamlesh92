package com.ecg.controllers;
import com.ecg.beans.Registration;
import com.ecg.services.RegistrationService;
import java.io.IOException;
import java.sql.ResultSet;
//import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class RegistrationServlet
 */
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("uname");  
		String password = request.getParameter("upswd");
		String role=request.getParameter("urole");
		int amount=Integer.parseInt(request.getParameter("amount"));
        Registration registration = new Registration( );     
		registration.setName(name);		      
		registration.setPassword(password);		       
		registration.setRole(role);		
		registration.setAmount(amount);	
		RegistrationService registrationService = new RegistrationService() ;		
		try{	
			  
                        int res = registrationService.addNewUser(registration);
                        if(res>0){
                        	ResultSet rs=null;
               			 	rs= registrationService.getDetails(registration);
               			 	HttpSession session=request.getSession();
               			 	while(rs.next()){
               				 session.setAttribute("id",rs.getInt(1));
               				 session.setAttribute("name",rs.getString(2));
               				 session.setAttribute("role",rs.getString(4));
               				 session.setAttribute("amount", rs.getInt(5));
               				 session.setAttribute("date", rs.getDate(6));	
               				 request.setAttribute("msg", "Successfully registered");
               				 RequestDispatcher rd=request.getRequestDispatcher("/RegistrationController.jsp");
               			     rd.include(request, response); 
               			 	} 
                        }
                        else{
                            request.setAttribute("msg", "fail");
                            RequestDispatcher rd = request.getRequestDispatcher("/Registration.html");      
                            rd.include(request, response);
                        }
		}
            catch(ClassNotFoundException ce ){		           
				ce.printStackTrace();      
		// append message to log file      
            }
                catch(SQLException se){		           
	    		se.printStackTrace( );		          
		 // append message to log file		       
		}   
		//RequestDispatcher rd = request.getRequestDispatcher("/Registration.html");      
		//rd.include(request, response);
	}
}



