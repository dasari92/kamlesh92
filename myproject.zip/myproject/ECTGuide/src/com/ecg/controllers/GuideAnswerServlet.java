package com.ecg.controllers;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ecg.beans.Guide;
import com.ecg.services.GuideAnswerService;
public class GuideAnswerServlet extends HttpServlet {
 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
public GuideAnswerServlet(){
	 super();
	  
 }
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	 HttpSession session=request.getSession();
	 int guideId=(int)session.getAttribute("Name");
	 int questionId = Integer.parseInt(request.getParameter("quesid"));
	 String answers = request.getParameter("atext");
	 Guide guide=new Guide();
	 guide.setGuideId(guideId);
	 guide.setQuestionId(questionId);
	 guide.setAnswers(answers);
	 GuideAnswerService answerService=new GuideAnswerService();
	 try{
		 int res=answerService.guideAnswer(guide);
		 if(res>0){
             request.setAttribute("msg","Successfully answered");
             RequestDispatcher rd = request.getRequestDispatcher("/GuideAnswerJsp.jsp");      
             rd.include(request, response);
         }
         else{
             request.setAttribute("msg", "fail");
             RequestDispatcher rd = request.getRequestDispatcher("/GuideAnswer.html");      
             rd.include(request, response);
         }
	 }
	 catch(ClassNotFoundException ce ){		           
			ce.printStackTrace();      
	// append message to log file      
	}
         catch(SQLException se){		           
 		se.printStackTrace( );		          
	 // append message to log file		       
	} 

 
 }
}