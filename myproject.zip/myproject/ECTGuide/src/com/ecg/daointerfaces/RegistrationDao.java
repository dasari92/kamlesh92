package com.ecg.daointerfaces;
import com.ecg.beans.Registration;

import java.sql.ResultSet;
import java.sql.SQLException;
public interface RegistrationDao {
	//public abstract List getAllUserDetails( ) throws ClassNotFoundException, SQLException;
	 
	   public abstract int addNewUser(Registration registration ) throws ClassNotFoundException, SQLException;
           public abstract ResultSet getDetails(Registration registration) throws ClassNotFoundException,SQLException;

	}


