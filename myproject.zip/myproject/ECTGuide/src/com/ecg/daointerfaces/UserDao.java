package com.ecg.daointerfaces;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface UserDao {
	public abstract ResultSet displayQuestions() throws ClassNotFoundException, SQLException;
}
