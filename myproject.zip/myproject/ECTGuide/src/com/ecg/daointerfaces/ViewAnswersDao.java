package com.ecg.daointerfaces;
import java.sql.ResultSet;
//import java.sql.Array;
import java.sql.SQLException;
//import java.util.List;
public interface ViewAnswersDao {
	public abstract ResultSet viewAnswers(int qid)throws ClassNotFoundException,SQLException;
}
