package com.ecg.daointerfaces;

import java.sql.SQLException;

import com.ecg.beans.User;

public interface UserQuestionDao {
 public abstract int postQuestion(User user)throws ClassNotFoundException,SQLException;
}
