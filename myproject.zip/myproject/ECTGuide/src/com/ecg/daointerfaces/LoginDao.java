package com.ecg.daointerfaces;
import com.ecg.beans.Login;
import java.sql.SQLException;
public interface LoginDao {
	   public abstract String validateUser(Login login) throws ClassNotFoundException, SQLException;
}
