package com.ecg.daointerfaces;
import java.sql.SQLException;
import com.ecg.beans.Feedback;
public interface UserFeedBackDao {
	 public abstract int sendFeedback(Feedback feedback) throws ClassNotFoundException, SQLException;
}
