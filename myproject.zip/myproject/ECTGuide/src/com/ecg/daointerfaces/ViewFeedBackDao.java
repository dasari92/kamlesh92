package com.ecg.daointerfaces;
import java.sql.ResultSet;
import java.sql.SQLException;
public interface ViewFeedBackDao {
	public abstract ResultSet viewFeedBack(int gid)throws ClassNotFoundException,SQLException;
}
