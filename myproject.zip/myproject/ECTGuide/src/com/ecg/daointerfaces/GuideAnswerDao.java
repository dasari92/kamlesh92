package com.ecg.daointerfaces;
import com.ecg.beans.Guide;
import java.sql.SQLException;
public interface GuideAnswerDao {
		public abstract int guideAnswer(Guide guide) throws	ClassNotFoundException, SQLException;
}

