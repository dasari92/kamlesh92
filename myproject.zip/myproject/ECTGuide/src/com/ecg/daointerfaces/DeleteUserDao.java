package com.ecg.daointerfaces;

import java.sql.SQLException;

public interface DeleteUserDao {
 public  abstract int deleteUser(int id) throws ClassNotFoundException, SQLException;
}