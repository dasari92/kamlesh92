package com.ecg.beans;

import java.io.Serializable;

public class Guide implements Serializable{
private int guideId;
private int questionId;
private String answers;
public Guide() {
	super();
}
public int getGuideId() {
	return guideId;
}
public void setGuideId(int guideId) {
	this.guideId = guideId;
}
public int getQuestionId() {
	return questionId;
}
public void setQuestionId(int questionId) {
	this.questionId = questionId;
}
public String getAnswers() {
	return answers;
}
public void setAnswers(String answers) {
	this.answers = answers;
}
@Override
public String toString() {
	return  "questionId=" + questionId
			+ ", answers=" + answers+ ", guideId=" + guideId;
}

}