package com.ecg.beans;

import java.io.Serializable;

public class User implements Serializable{
	private int userId;
	private String question;
	//private int questionId;
	public User(){
		super();
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	//public int getQuestionId() {
		//return questionId;
	//}
	//public void setQuestionId(int questionId) {
		//this.questionId = questionId;
	//}
	@Override
	public String toString() {
		return "question=" + question+ ",userId="+userId;
	}
	
}
