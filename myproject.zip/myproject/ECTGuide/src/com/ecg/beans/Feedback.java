package com.ecg.beans;

import java.io.Serializable;

public class Feedback implements Serializable{
private int guideId;
//private double amountCredited;
private String feebackText;
public Feedback() {
super();
}
public int getGuideId() {
	return guideId;
}
public void setGuideId(int guideId) {
	this.guideId = guideId;
}
/*public double getAmountCredited() {
	return amountCredited;
}
public void setAmountCredited(double amountCredited) {
	this.amountCredited = amountCredited;
}*/
public String getFeebackText() {
	return feebackText;
}
public void setFeebackText(String feebackText) {
	this.feebackText = feebackText;
}
/**
 * @Override
 * @return
 */
public String toString() {
	return "guideid=" + guideId + ", feebackText=" + feebackText;
}

}

