package com.ecg.beans;
import java.io.Serializable;
public class Registration implements Serializable{
	private String name;
    //private int id;
    private String password;
    private String role;
    private int amount;
    //private String date;
	public Registration() {
		super();
	}
	public Registration(String name,String password,String role,int amount){
		this.name=name;
		this.password=password;
		this.role=role;
		this.amount=amount;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	/*public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}*/
	@Override
	public String toString() {
		return "name=" + name +", password="
				+ password + ", role=" + role + ", amount=" + amount;
	}
}
